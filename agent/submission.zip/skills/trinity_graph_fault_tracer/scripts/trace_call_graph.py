#!/usr/bin/env python3
import argparse, ast, os
from collections import defaultdict
from pathlib import Path

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--symbol", "-s", required=True)
    p.add_argument("--workspace", "-w", default="/workspace")
    args = p.parse_args()
    ws = Path(args.workspace) if Path(args.workspace).exists() else Path(".")
    defs, calls, callers = {}, defaultdict(set), defaultdict(set)
    for root, dirs, files in os.walk(ws):
        dirs[:] = [d for d in dirs if not d.startswith(".") and d not in ("__pycache__", "venv", "env")]
        for f in files:
            if not f.endswith(".py"): continue
            fp = Path(root) / f
            rel = str(fp.relative_to(ws))
            try:
                tree = ast.parse(fp.read_text(encoding="utf-8", errors="replace"))
                for n in ast.walk(tree):
                    if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
                        defs[n.name] = f"{rel}:{n.lineno}-{getattr(n, 'end_lineno', n.lineno+20)}"
                        for sub in ast.walk(n):
                            if isinstance(sub, ast.Call):
                                cname = sub.func.id if isinstance(sub.func, ast.Name) else (sub.func.attr if isinstance(sub.func, ast.Attribute) else None)
                                if cname:
                                    calls[n.name].add(cname)
                                    callers[cname].add(n.name)
            except Exception:
                continue
    t = args.symbol.split(".")[-1]
    print(f"[DEFINITION]: {defs.get(t, 'Not found')}")
    print(f"[CALLERS]: {sorted(callers.get(t, set()))[:15]}")
    print(f"[CALLEES]: {sorted(calls.get(t, set()))[:15]}")

if __name__ == "__main__":
    main()
