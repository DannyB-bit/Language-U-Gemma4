---
name: trinity_graph_fault_tracer
description: AST Call-Graph Fault Tracer ported from Consider-Trinity.
---
Run `python3 skills/trinity_graph_fault_tracer/scripts/trace_call_graph.py --symbol "<func>" --workspace /workspace`
