#!/usr/bin/env python3
import argparse, ast, hashlib, json, subprocess, sys, tempfile
from pathlib import Path

STATE = Path(tempfile.gettempdir()) / "trinity_e4b_kalman_history.json"

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--workspace", "-w", default="/workspace")
    p.add_argument("--test", "-t", default=None)
    args = p.parse_args()
    ws = Path(args.workspace) if Path(args.workspace).exists() else Path(".")
    diff = subprocess.run(["git", "diff", "HEAD"], cwd=ws, capture_output=True, text=True).stdout.strip()
    if not diff:
        print("[TRINITY_VERIFIER]: NO_DIFF")
        sys.exit(1)
    h = hashlib.sha256(diff.encode()).hexdigest()[:16]
    hist = json.loads(STATE.read_text()) if STATE.exists() else []
    if h in hist:
        print("[KALMAN_LOOP_ALERT]: Duplicate patch state detected! Revert and try #2 locus.")
    hist.append(h)
    STATE.write_text(json.dumps(hist[-12:]))
    changed = subprocess.run(["git", "diff", "--name-only", "HEAD"], cwd=ws, capture_output=True, text=True).stdout.splitlines()
    for rel in changed:
        if rel.endswith(".py") and (ws / rel).exists():
            try:
                ast.parse((ws / rel).read_text(encoding="utf-8"))
                print(f"[AST_OK]: {rel}")
            except SyntaxError as e:
                print(f"[AST_ERROR]: {rel}:{e.lineno}: {e.msg}")
                sys.exit(2)
    if args.test:
        r = subprocess.run(["pytest", args.test, "--tb=short", "-q"], cwd=ws, capture_output=True, text=True, timeout=30)
        print(r.stdout[-1200:])
        print("[PYTEST_PASS]" if r.returncode == 0 else "[PYTEST_FAIL]")
        sys.exit(r.returncode)

if __name__ == "__main__":
    main()
