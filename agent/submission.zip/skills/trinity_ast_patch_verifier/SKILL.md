---
name: trinity_ast_patch_verifier
description: AST Syntax + Tier-2 Kalman Loop Detector + Pytest Gate.
---
Run `python3 skills/trinity_ast_patch_verifier/scripts/verify_patch_ast.py --workspace /workspace --test "<test_path>"`
