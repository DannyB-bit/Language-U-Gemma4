---
name: trinity_hybrid_locator
description: BM25 + 8D S^7 Octonion Geodesic Reciprocal Rank Fusion (RRF) & Two-Tier Trust Gate.
---
Run `python3 skills/trinity_hybrid_locator/scripts/hybrid_locate.py --query "<symbol>" --workspace /workspace`
