#!/usr/bin/env python3
import argparse, ast, math, os, re, sys
from pathlib import Path

def project_to_s7(text: str):
    coords = [0.0] * 8
    for idx, tok in enumerate(re.findall(r"[a-zA-Z0-9_]+", text.lower())[:64]):
        h = sum((i + 1) * ord(c) for i, c in enumerate(tok)) & 0xFFFFFFFF
        for d in range(8):
            coords[d] += math.sin(((h + d * 1024 + idx * 17) % 360) * math.pi / 180.0)
    n = math.sqrt(sum(x * x for x in coords))
    return [x / n for x in coords] if n > 1e-8 else [1.0] + [0.0] * 7

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--query", "-q", required=True)
    p.add_argument("--workspace", "-w", default="/workspace")
    p.add_argument("--top-k", "-k", type=int, default=5)
    args = p.parse_args()
    ws = Path(args.workspace) if Path(args.workspace).exists() else Path(".")
    chunks = []
    for root, dirs, files in os.walk(ws):
        dirs[:] = [d for d in dirs if not d.startswith(".") and d not in ("__pycache__", "venv", "env", "build", "dist")]
        for f in files:
            if not f.endswith(".py"): continue
            fp = Path(root) / f
            rel = str(fp.relative_to(ws))
            try:
                src = fp.read_text(encoding="utf-8", errors="replace")
                lines = src.splitlines()
                tree = ast.parse(src)
                for node in ast.walk(tree):
                    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                        s, e = getattr(node, "lineno", 1), getattr(node, "end_lineno", 30)
                        prev = "\n".join(lines[s-1:min(s+14, e)])
                        chunks.append({"file": rel, "symbol": node.name, "start": s, "end": e, "text": f"{rel} {node.name} {prev}", "preview": prev})
            except Exception:
                continue
    q_toks = [t.lower() for t in re.findall(r"[a-zA-Z0-9_]+", args.query) if len(t) >= 2]
    q_s7 = project_to_s7(args.query)
    scored = []
    for idx, ch in enumerate(chunks):
        toks = set(re.findall(r"[a-zA-Z0-9_]+", ch["text"].lower()))
        ov = sum(1 for t in q_toks if t in toks)
        boost = sum(2.5 if t == ch["symbol"].lower() else 1.0 for t in q_toks if t in toks)
        c_s7 = project_to_s7(ch["symbol"] + " " + ch["preview"])
        sim = sum(a * b for a, b in zip(q_s7, c_s7))
        scored.append((ov, boost + 0.4 * sim, sim, ch))
    scored.sort(key=lambda x: (x[0] > 0, x[1]), reverse=True)
    if not scored or scored[0][0] == 0:
        print("[TRINITY_TRUST_GATE]: MISS — No lexical/octonionic match in workspace.")
        sys.exit(0)
    tier = "STRONG" if scored[0][0] >= 2 else "WEAK"
    print(f"[TRINITY_TRUST_GATE]: {tier} (Scanned {len(chunks)} AST symbols)")
    for rank, (ov, sc, sim, ch) in enumerate(scored[:args.top_k], 1):
        print(f"\n[{rank}] {ch['file']}:{ch['start']}-{ch['end']} (`{ch['symbol']}` | score={sc:.3f} | S^7={sim:.3f})")
        print(ch["preview"])

if __name__ == "__main__":
    main()
